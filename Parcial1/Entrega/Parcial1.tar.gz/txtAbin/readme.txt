Para ejecutar el programa se debe introducir el siguiente comando:
/*

./bin/Debug/txtAbin nombreArchivoTexto.txt nombreArchivoBinario.bin

*/